from stratum.custom_exceptions import ServiceException

class SubmitException(ServiceException):
    pass